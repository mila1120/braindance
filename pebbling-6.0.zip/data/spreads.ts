
export interface CardPosition {
  n: number | string;
  top: string;
  left: string;
  rotate?: number;
}

export interface SpreadConfig {
  title: string;
  layout: CardPosition[];
  sections: { id: string; label: string; cards: (number|string)[] }[];
}

export const SPREADS: Record<string, SpreadConfig> = {
  moon: {
    title: "Moon",
    layout: [
      { n: 5, top: "25%", left: "25%" }, { n: 4, top: "25%", left: "75%" },
      { n: 7, top: "45%", left: "25%" }, { n: 6, top: "45%", left: "50%" }, { n: 3, top: "45%", left: "75%" },
      { n: 1, top: "65%", left: "25%" }, { n: 8, top: "65%", left: "75%" },
      { n: 2, top: "85%", left: "50%" }
    ],
    sections: [
      { id: 'core', label: 'The Core', cards: [7] },
      { id: 'env', label: 'The Environment', cards: [3, 5, 8, 4, 1, 2, 6] },
      { id: 'path', label: 'Unfolding Path', cards: [5, 8, 1, 6, 2, 4, 3] },
      { id: 'insight', label: 'Deep Insight', cards: [7, 1, 2, 3, 4, 5, 6, 8] },
    ]
  },
  happiness: {
    title: "Happiness",
    layout: [
      { n: 5, top: "30%", left: "15%" }, { n: 6, top: "30%", left: "32.5%" }, { n: 1, top: "30%", left: "50%" }, { n: 2, top: "30%", left: "67.5%" }, { n: 3, top: "30%", left: "85%" },
      { n: 4, top: "55%", left: "35%" }, { n: 7, top: "55%", left: "65%" },
      { n: 8, top: "75%", left: "50%" },
    ],
    sections: [
      { id: 'core', label: 'The Core', cards: [1, 2] },
      { id: 'env', label: 'The Environment', cards: [5, 6, 3, 4, 7] },
      { id: 'path', label: 'The Path', cards: [8, 4, 7] },
      { id: 'insight', label: 'Insight', cards: [1, 2, 3, 4, 5, 6, 7, 8] },
    ]
  },
  insane: {
    title: "Insane",
    layout: [
       { n: 4, top: "12%", left: "80%" }, { n: 5, top: "32%", left: "80%" }, { n: 3, top: "52%", left: "80%" },
       { n: 6, top: "35%", left: "50%" }, { n: 7, top: "55%", left: "50%" }, { n: 8, top: "75%", left: "50%" },
       { n: 1, top: "58%", left: "20%" }, { n: 10, top: "78%", left: "20%" }, { n: 9, top: "78%", left: "50%" }
    ],
    sections: [
      { id: 'core', label: 'The Core', cards: [6, 7] },
      { id: 'env', label: 'The Chaos', cards: [4, 5, 3, 8] },
      { id: 'path', label: 'The Descent', cards: [1, 10, 9] },
      { id: 'insight', label: 'The Reality', cards: [1, 3, 4, 5, 6, 7, 8, 9, 10] },
    ]
  },
  dream: {
    title: "Dream",
    layout: [
       { n: 5, top: "30%", left: "20%" }, { n: 7, top: "50%", left: "28%" }, { n: 1, top: "70%", left: "20%" },
       { n: 6, top: "50%", left: "50%" }, { n: 2, top: "80%", left: "50%" },
       { n: 4, top: "30%", left: "80%" }, { n: 3, top: "50%", left: "72%" }, { n: 8, top: "70%", left: "80%" }
    ],
    sections: [
      { id: 'core', label: 'The Dreamer', cards: [6, 2] },
      { id: 'env', label: 'The Symbols', cards: [5, 7, 1] },
      { id: 'path', label: 'The Narrative', cards: [4, 3, 8] },
      { id: 'insight', label: 'Awakening', cards: [1, 2, 3, 4, 5, 6, 7, 8] },
    ]
  },
  flow: {
    title: "Flow of Music",
    layout: [
      { n: 1, top: "60%", left: "50%" },
      { n: 2, top: "45%", left: "38%", rotate: -15 }, { n: 3, top: "30%", left: "28%", rotate: -30 }, { n: 5, top: "48%", left: "22%", rotate: -15 }, { n: 8, top: "65%", left: "15%", rotate: 15 },
      { n: 4, top: "45%", left: "62%", rotate: 15 }, { n: 6, top: "30%", left: "72%", rotate: 30 }, { n: 7, top: "48%", left: "78%", rotate: 15 }, { n: 9, top: "65%", left: "85%", rotate: -15 }
    ],
    sections: [
      { id: 'core', label: 'The Melody', cards: [1] },
      { id: 'env', label: 'The Rhythm', cards: [2, 3, 5, 8] },
      { id: 'path', label: 'The Harmony', cards: [4, 6, 7, 9] },
      { id: 'insight', label: 'The Song', cards: [1, 2, 3, 4, 5, 6, 7, 8, 9] },
    ]
  },
  anxiety: {
    title: "Anxiety",
    layout: [
      { n: 6, top: "28%", left: "25%" }, { n: 1, top: "25%", left: "50%" }, { n: 9, top: "28%", left: "75%" },
      { n: 3, top: "45%", left: "15%" }, { n: 5, top: "45%", left: "38%" }, { n: 11, top: "45%", left: "62%" }, { n: 8, top: "45%", left: "85%" },
      { n: 7, top: "65%", left: "32%" }, { n: 10, top: "65%", left: "68%" },
      { n: 2, top: "80%", left: "50%" }
    ],
    sections: [
      { id: 'core', label: 'The Fear', cards: [1, 5, 11] },
      { id: 'env', label: 'The Triggers', cards: [6, 9, 3, 8] },
      { id: 'path', label: 'The Grounding', cards: [7, 10, 2] },
      { id: 'insight', label: 'Release', cards: [1, 2, 3, 5, 6, 7, 8, 9, 10, 11] },
    ]
  },
  protection: {
    title: "Protection",
    layout: [
      { n: 6, top: "25%", left: "50%" }, { n: 2, top: "38%", left: "50%" }, { n: 1, top: "50%", left: "50%" }, { n: 3, top: "62%", left: "50%" }, { n: 10, top: "75%", left: "50%" },
      { n: 8, top: "50%", left: "12%" }, { n: 4, top: "50%", left: "30%" }, { n: 5, top: "50%", left: "70%" }, { n: 12, top: "50%", left: "88%" },
      { n: 7, top: "32%", left: "22%", rotate: -45 }, { n: 13, top: "32%", left: "78%", rotate: 45 },
      { n: 6, top: "68%", left: "22%", rotate: 45 }, { n: 11, top: "68%", left: "78%", rotate: -45 }
    ],
    sections: [
      { id: 'core', label: 'The Shield', cards: [1, 2, 3] },
      { id: 'env', label: 'The Threat', cards: [6, 10, 8, 12] },
      { id: 'path', label: 'The Ward', cards: [4, 5, 7, 13, 11] },
      { id: 'insight', label: 'Sanctuary', cards: [1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13] },
    ]
  }
};
    