export interface Pebble {
  id: string;
  date: string; // ISO string
  timestamp: number;
  dreamText: string;
  analysis: string;
  sentiment: 'calm' | 'anxious' | 'joyful' | 'mysterious' | 'sad';
  color: string;
  videoUrl?: string; // For Veo generated videos
  position: { x: number; y: number }; // For visual layout in the Nest
  scale: number;
}

export type ViewState = 
  | 'NEST' 
  | 'ANALYSE' 
  | 'LUCK' 
  | 'CHAT' 
  | 'ADD_DREAM' 
  | 'PEBBLE_DETAIL' 
  | 'ANALYZING'
  | 'LUCK_INPUT'
  | 'LUCK_SELECTING'
  | 'LUCK_REVEAL';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface DreamSpreadResult {
  coreAtmosphere: string; // Card 7
  presentSituation: string; // Outer Ring (Method 1)
  unfoldingPath: string; // Time sequence (Method 2)
  insight: string; // Deeper looking / "Seeing"
  visualTheme: string;
}