import { GoogleGenAI, Type } from "@google/genai";
import { Pebble, DreamSpreadResult } from '../types';
import { DREAM_ANALYSIS_PROMPT } from '../prompts/dreamAnalysis';
import { CHAT_SYSTEM_INSTRUCTION } from '../prompts/chatSystem';
import { FORTUNE_PROMPT } from '../prompts/fortunePrompt';

// Analyze a dream text using Gemini and return structured dream data
export const analyzeDream = async (dreamText: string): Promise<Partial<Pebble>> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: DREAM_ANALYSIS_PROMPT.replace("{dreamText}", dreamText),
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dreamType: { type: Type.STRING },
            symbolAnalysis: { type: Type.STRING },
            emotionsDesires: { type: Type.STRING },
            fullInterpretation: { type: Type.STRING },
            mythConnection: { type: Type.STRING },
            sentiment: { type: Type.STRING },
            color: { type: Type.STRING },
          },
          required: ["dreamType", "symbolAnalysis", "emotionsDesires", "fullInterpretation", "mythConnection", "sentiment", "color"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    const parsed = JSON.parse(text);
    const analysis = `
✨ **Dream Type**: ${parsed.dreamType}

🌙 **Symbol & Behavior Analysis**: ${parsed.symbolAnalysis}

💛 **Emotions & Desires**: ${parsed.emotionsDesires}

📖 **Full Dream Interpretation**: ${parsed.fullInterpretation}

🌀 **Folklore / Myth Connection**: ${parsed.mythConnection}
    `.trim();

    return {
      ...parsed,
      analysis: analysis,
      color: parsed.color,
      sentiment: parsed.sentiment
    };
  } catch (error) {
    console.error("Analysis failed:", error);
    return {
      analysis: "✨ The mists of your mind are thick today. The meaning remains obscured, yet felt. 🌙 Your subconscious is resting, waiting for the right moment to speak. 💛 Be patient with yourself.",
      sentiment: 'mysterious',
      color: '#888888'
    };
  }
};

export const getFortune = async (question: string): Promise<DreamSpreadResult> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: FORTUNE_PROMPT.replace("{question}", question),
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            coreAtmosphere: { type: Type.STRING },
            presentSituation: { type: Type.STRING },
            unfoldingPath: { type: Type.STRING },
            insight: { type: Type.STRING },
            visualTheme: { type: Type.STRING },
          },
          required: ["coreAtmosphere", "presentSituation", "unfoldingPath", "insight", "visualTheme"],
        },
      },
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Fortune failed:", error);
    return {
      coreAtmosphere: "The center is still, like the eye of a storm. There is a silent rule governing this moment.",
      presentSituation: "Chaos surrounds the center. Conflicting interests and noise are making it hard to see clearly.",
      unfoldingPath: "Events are moving in a cycle. What feels like a straight line is actually a curve returning to the start.",
      insight: "Look not with your eyes, but with your intuition. The truth is hidden in plain sight.",
      visualTheme: "moonlight on dark water"
    };
  }
};

export const createChat = () => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: CHAT_SYSTEM_INSTRUCTION,
    },
  });
};

export const generateDreamVideo = async (imageBase64: string, mimeType: string, prompt: string = "A dreamlike sequence"): Promise<string | null> => {
  try {
    const win = window as any;
    if (win.aistudio) {
        const hasKey = await win.aistudio.hasSelectedApiKey();
        if (!hasKey) {
            await win.aistudio.openSelectKey();
        }
    }

    const veoAi = new GoogleGenAI({ apiKey: process.env.API_KEY });

    let operation = await veoAi.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt, 
      image: {
        imageBytes: imageBase64,
        mimeType: mimeType,
      },
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '9:16'
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await veoAi.operations.getVideosOperation({operation: operation});
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) throw new Error("No video generated");

    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    if (!response.ok) throw new Error("Failed to download video");
    const blob = await response.blob();
    return URL.createObjectURL(blob);

  } catch (error) {
    console.error("Veo generation failed:", error);
    throw error;
  }
};