import React, { useState, useEffect } from 'react';
import { ViewState, Pebble, DreamSpreadResult } from './types';
import Nest from './components/Nest';
import NavBar from './components/NavBar';
import DreamInput from './components/DreamInput';
import PebbleDetail from './components/PebbleDetail';
import ChatBot from './components/ChatBot';
import VeoStudio from './components/VeoStudio';
import ArchitectureDiagram from './components/ArchitectureDiagram';
import Onboarding from './components/Onboarding';
import AnalyzingScreen from './components/AnalyzingScreen';
import CustomCursor from './components/CustomCursor';
import LuckDashboard from './components/LuckDashboard';
import LuckInput from './components/LuckInput';
import LuckSelecting from './components/LuckSelecting';
import LuckReveal from './components/LuckReveal';
import { analyzeDream, getFortune } from './services/gemini';
import { Plus, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const MOCK_PEBBLES: Pebble[] = [
  {
    id: 'pebble-27',
    date: new Date().toISOString(),
    timestamp: Date.now(),
    dreamText: "That night's dream unfolded slowly, like walking through fog with a sense that something important was nearby.",
    analysis: `✨ **Dream Type**: A hazy, sensory-driven fragment of exploration.

🌙 **Symbol & Behavior Analysis**: The fog represents a threshold of consciousness where the known meets the unknown. Walking through it suggests a transition or a search for clarity in a confusing period.

💛 **Emotions & Desires**: Curiosity mixed with a quiet pull forward. You are longing for a signal or a sign of direction. 🌫️

📖 **Full Dream Interpretation**: This dream holds a moment of inner listening: a mix of uncertainty and restrained desire. It suggests that clarity will arrive through subtle signals rather than sudden answers.

🌀 **Folklore / Myth Connection**: In many cultures, fog is a 'thin place' where the barrier between the earthly and the spirit world is porous.`,
    sentiment: 'mysterious',
    color: '#E0E0E0',
    position: { x: -40, y: 100 },
    scale: 1.1,
  },
  {
    id: 'pebble-14',
    date: new Date(Date.now() - 86400000).toISOString(),
    timestamp: Date.now() - 86400000,
    dreamText: "Running down an endless spiral staircase, deeper and deeper.",
    analysis: `✨ **Dream Type**: A kinetic, repetitive emotional loop.

🌙 **Symbol & Behavior Analysis**: The spiral staircase is a classic symbol of descent into the self. Going deeper suggests looking for a root cause or a core truth.

💛 **Emotions & Desires**: Anxiety fueled by a need for safety while standing at the edge of change. 🌀

📖 **Full Dream Interpretation**: Descent is not always a fall; sometimes it is a journey to the center. You are seeking a core truth that lies beneath surface anxieties.

🌀 **Folklore / Myth Connection**: Spirals represent the path of evolution and the turning of the seasons in ancient Celtic lore.`,
    sentiment: 'anxious',
    color: '#444444',
    position: { x: 30, y: 130 },
    scale: 0.85,
  }
];

const App: React.FC = () => {
  const [hasStarted, setHasStarted] = useState(false);
  const [view, setView] = useState<ViewState>('ADD_DREAM');
  const [pebbles, setPebbles] = useState<Pebble[]>(MOCK_PEBBLES);
  const [selectedPebble, setSelectedPebble] = useState<Pebble | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showVeoStudio, setShowVeoStudio] = useState(false);
  const [showArchitecture, setShowArchitecture] = useState(false);
  
  // Luck state
  const [fortune, setFortune] = useState<DreamSpreadResult | null>(null);
  const [luckCategory, setLuckCategory] = useState<string>('moon');

  const handleVeoVideoGenerated = (url: string) => {
    if (selectedPebble) {
      const updatedPebble = { ...selectedPebble, videoUrl: url };
      setPebbles(prev => prev.map(p => p.id === selectedPebble.id ? updatedPebble : p));
      setSelectedPebble(updatedPebble);
    }
    setShowVeoStudio(false);
  };

  const handleAddDream = async (text: string) => {
    setIsProcessing(true);
    setView('ANALYZING');
    
    try {
      const analysisData = await analyzeDream(text);
      
      // Generate position in the bottom hemisphere (gravity effect)
      // Angle between 0.2 PI and 0.8 PI (downward arc)
      const angle = (Math.PI * 0.2) + (Math.random() * Math.PI * 0.6); 
      // Push towards the bottom edge, radius 70-130px (Nest is ~380px wide -> 190 radius)
      const radius = 70 + Math.random() * 70; 
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;

      const newPebble: Pebble = {
        id: `PEBB-${Math.floor(Math.random() * 9000 + 1000)}`,
        date: new Date().toISOString(),
        timestamp: Date.now(),
        dreamText: text,
        analysis: analysisData.analysis || "Analysis unavailable.",
        sentiment: (analysisData.sentiment as any) || 'mysterious',
        color: analysisData.color || '#888888',
        position: { x, y },
        scale: 0.65 + Math.random() * 0.45
      };

      setPebbles(prev => [...prev, newPebble]);
      setSelectedPebble(newPebble);
      
      setTimeout(() => {
        setView('PEBBLE_DETAIL');
        setHasStarted(true);
        setIsProcessing(false);
      }, 2000);

    } catch (e) {
      console.error(e);
      alert("Failed to analyze dream. Please try again.");
      setView('ADD_DREAM');
      setIsProcessing(false);
    }
  };

  const handleFortuneRequest = async (question: string) => {
    setView('LUCK_SELECTING');
    try {
      const result = await getFortune(question);
      setFortune(result);
    } catch (e) {
      console.error(e);
    }
  };

  const handleViewChange = (newView: ViewState) => {
    setView(newView);
  };

  if (!hasStarted && view === 'ADD_DREAM' && !isProcessing) {
    return (
      <AnimatePresence mode="wait">
        {!hasStarted && (
          <Onboarding 
            onComplete={() => {
              setHasStarted(true);
            }} 
          />
        )}
      </AnimatePresence>
    );
  }

  return (
    <div className="relative h-screen w-full overflow-hidden bg-[#000000] text-white font-sans selection:bg-white/20">
      <CustomCursor />
      
      <AnimatePresence mode="wait">
        {view === 'NEST' && (
           <motion.div 
             key="nest"
             initial={{ opacity: 0 }} 
             animate={{ opacity: 1 }} 
             exit={{ opacity: 0 }} 
             className="h-full w-full"
           >
              <Nest 
                pebbles={pebbles} 
                onPebbleClick={(p) => {
                  setSelectedPebble(p);
                  setView('PEBBLE_DETAIL');
                }} 
              />
              
              <div className="absolute top-8 left-8 z-[120]">
                <button 
                  onClick={() => setShowArchitecture(true)}
                  className="p-3 rounded-full bg-white/5 text-white/10 hover:text-white/30 transition-colors"
                >
                  <Info size={18} />
                </button>
              </div>

              <div className="absolute bottom-36 left-1/2 -translate-x-1/2 z-[120]">
                <button 
                  onClick={() => setView('ADD_DREAM')}
                  className="w-16 h-16 rounded-full bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-center text-white/40 hover:bg-white/10 hover:text-white/60 transition-all group shadow-xl"
                >
                  <Plus size={24} className="group-hover:rotate-90 transition-transform duration-700" />
                </button>
              </div>
           </motion.div>
        )}

        {view === 'ADD_DREAM' && (
           <DreamInput 
             key="add"
             onCancel={() => setView('NEST')} 
             onSubmit={handleAddDream}
             isProcessing={isProcessing}
             showCancel={hasStarted}
           />
        )}

        {view === 'ANALYZING' && (
           <AnalyzingScreen key="analyzing" />
        )}

        {view === 'CHAT' && (
            <ChatBot key="chat" onClose={() => setView('NEST')} />
        )}

        {view === 'LUCK' && (
             <LuckDashboard 
               key="luck_dash"
               onSelectCategory={(cat) => {
                 setLuckCategory(cat);
                 setView('LUCK_INPUT');
               }} 
               onBack={() => setView('NEST')}
             />
        )}

        {view === 'LUCK_INPUT' && (
          <LuckInput 
            key="luck_input"
            onBack={() => setView('LUCK')}
            onSubmit={handleFortuneRequest}
          />
        )}

        {view === 'LUCK_SELECTING' && (
          <LuckSelecting 
            key="luck_selecting"
            category={luckCategory}
            onSelected={() => setView('LUCK_REVEAL')}
          />
        )}

        {view === 'LUCK_REVEAL' && fortune && (
          <LuckReveal 
            key="luck_reveal"
            fortune={fortune}
            category={luckCategory}
            onDone={() => {
              setFortune(null);
              setView('LUCK');
            }}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {view === 'PEBBLE_DETAIL' && selectedPebble && (
          <PebbleDetail 
            key="pebble_detail"
            pebble={selectedPebble} 
            onClose={() => {
              setSelectedPebble(null);
              setView('NEST');
            }}
            onGenerateVideo={() => setShowVeoStudio(true)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showVeoStudio && selectedPebble && (
          <VeoStudio 
            pebble={selectedPebble}
            onClose={() => setShowVeoStudio(false)}
            onVideoGenerated={handleVeoVideoGenerated}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showArchitecture && (
          <ArchitectureDiagram onClose={() => setShowArchitecture(false)} />
        )}
      </AnimatePresence>

      {hasStarted && view !== 'ANALYZING' && view !== 'ADD_DREAM' && view !== 'PEBBLE_DETAIL' && (
        <NavBar currentView={view} onChangeView={handleViewChange} />
      )}
    </div>
  );
};

export default App;