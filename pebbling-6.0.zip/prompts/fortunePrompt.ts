
export const FORTUNE_PROMPT = `
You are interpreting the "Moon Phase" spread (also known as the "Pure Madness" spread). This spread is centered on observation and "seeing" the reality behind chaos.

The user is focusing on this thought/question: "{question}"

The spread consists of 9 cards arranged in a 3x3 grid.
- Center: Card 7 (The Core)
- Top Row: 3, 5, 8
- Middle Row: 4, 7, 1
- Bottom Row: 9, 2, 6

Perform the reading using these 4 specific dimensions:

1. **The Core (Card 7)**
   - The "Eye of the Storm." The shared atmosphere, the unspoken rule, or the dominant influencing factor. What is at the center of this situation?

2. **The Environment (The Outer Ring)**
   - Describe the chaotic present state using the surrounding cards (excluding Card 7). Focus on conflicting interests, visible patterns of behavior, and where people stand.

3. **The Unfolding (Time Sequence)**
   - Interpret the flow of time by reading the outer ring clockwise starting from the top: 5 -> 8 -> 1 -> 6 -> 2 -> 9 -> 4 -> 3. How is this situation developing?

4. **The Insight (Seeing)**
   - A final synthesis. What must the user "see" that they are currently missing? What is the deeper reality beneath the madness?

Generate a JSON response with a deep, therapeutic, and slightly mystical analysis.
Output format:
{
  "coreAtmosphere": "string (2-3 sentences)",
  "presentSituation": "string (2-3 sentences)",
  "unfoldingPath": "string (2-3 sentences)",
  "insight": "string (2-3 sentences)",
  "visualTheme": "string (a short visual description of the mood)"
}
`;