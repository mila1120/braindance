
export const DREAM_ANALYSIS_PROMPT = `
Analyze the following dream. Generate a concise, story-like dream analysis that is calming, readable, and therapeutic. 
Use friendly, slightly poetic language, and emojis to add life and emphasis.

Provide the analysis in the following JSON structure:
- "dreamType": 1-2 sentences describing the kind of dream (e.g., story-like, fragmentary, symbolic, emotional).
- "symbolAnalysis": 2-3 sentences identifying key symbols/actions (e.g., flying, being chased) and explaining their possible meaning.
- "emotionsDesires": 1-2 sentences analyzing potential underlying emotions or subconscious drives (e.g., fear, longing). Use emojis.
- "fullInterpretation": 2-3 sentences combining symbols, behaviors, and emotions into a complete story-like interpretation of the user's inner world.
- "mythConnection": 1-2 sentences adding a cultural or mythological note related to the symbols.
- "sentiment": One of the following exact strings: 'calm', 'anxious', 'joyful', 'mysterious', 'sad'.
- "color": A suggested grayscale hex color code (ranging from #222222 to #FFFFFF).

Dream: "{dreamText}"
`;
