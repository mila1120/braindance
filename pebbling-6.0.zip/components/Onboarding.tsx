import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface OnboardingProps {
  onComplete: () => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [stage, setStage] = useState<'DROP' | 'RIPPLES' | 'LOGO' | 'FINISHED'>('DROP');

  useEffect(() => {
    // Sequence timing
    const timers = [
      setTimeout(() => setStage('RIPPLES'), 1000), // Drop duration
      setTimeout(() => setStage('LOGO'), 3000),    // Ripples duration
      setTimeout(() => setStage('FINISHED'), 6000),
      setTimeout(() => onComplete(), 7000),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[200] bg-black flex items-center justify-center overflow-hidden font-sans">
      
      {/* 1. The Drop Phase */}
      <AnimatePresence>
        {stage === 'DROP' && (
          <motion.div
            initial={{ y: '-50vh', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ opacity: 0, scale: 1.2, transition: { duration: 0.2 } }}
            transition={{ 
              duration: 1.0, 
              ease: [0.16, 1, 0.3, 1] // Custom ease for a smooth, heavy drop
            }}
            className="absolute z-20 flex items-center justify-center"
          >
            {/* Specified Oval Shape: 58x46 px */}
            <div className="w-[58px] h-[46px] bg-[#D9D9D9] rounded-[50%] blur-[0.5px] shadow-[0_0_30px_rgba(255,255,255,0.2)]" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Impact & Ripples Phase */}
      <AnimatePresence>
        {(stage === 'RIPPLES' || stage === 'LOGO') && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
            {/* Expanding soft ripple lines */}
            {[0, 1, 2, 3].map((i) => (
              <motion.div
                key={i}
                initial={{ width: '58px', height: '46px', opacity: 0.6, borderWidth: '1.5px' }}
                animate={{ 
                  width: '120vmax', 
                  height: '120vmax', 
                  opacity: 0,
                  borderWidth: '0px'
                }}
                transition={{
                  duration: 4,
                  delay: i * 0.4,
                  ease: "easeOut",
                }}
                className="absolute rounded-full border-white/40"
                style={{
                    boxShadow: '0 0 20px rgba(255,255,255,0.05)'
                }}
              />
            ))}
            
            {/* Flash at impact center */}
            {stage === 'RIPPLES' && (
                 <motion.div 
                    initial={{ opacity: 0.6, scale: 1 }}
                    animate={{ opacity: 0, scale: 2.5 }}
                    transition={{ duration: 1.2, ease: "easeOut" }}
                    className="w-[58px] h-[46px] bg-white rounded-[50%] blur-[15px]"
                 />
            )}
          </div>
        )}
      </AnimatePresence>

      {/* 3. Logo Reveal Phase */}
      <AnimatePresence>
        {stage === 'LOGO' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, filter: 'blur(10px)' }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="relative z-30 flex flex-col items-center justify-center"
          >
            {/* Subtle Orbit Ring appearing with logo */}
             <motion.div 
               initial={{ opacity: 0, scale: 0.8 }}
               animate={{ opacity: 1, scale: 1 }}
               transition={{ duration: 1.5, ease: "easeOut" }}
               className="absolute w-[240px] h-[240px] rounded-full border border-white/10 blur-[1px]"
             />

             {/* Text */}
            <h1 className="text-3xl font-light tracking-[0.3em] text-white/90 uppercase ml-1">
              Pebble
            </h1>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Final Transition Phase */}
      {stage === 'FINISHED' && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="absolute inset-0 bg-black z-50"
        />
      )}
    </div>
  );
};

export default Onboarding;