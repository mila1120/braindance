import React, { useEffect, useState } from 'react';
import { motion, useSpring, useMotionValue } from 'framer-motion';

const CustomCursor: React.FC = () => {
  const [isClicking, setIsClicking] = useState(false);
  
  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);

  // Faster spring for direct feedback
  const springConfig = { damping: 20, stiffness: 300 };
  const cursorXSpring = useSpring(cursorX, springConfig);
  const cursorYSpring = useSpring(cursorY, springConfig);

  useEffect(() => {
    const root = document.getElementById('root');
    const initialRect = root?.getBoundingClientRect();
    cursorX.set(initialRect ? initialRect.width / 2 : window.innerWidth / 2);
    cursorY.set(initialRect ? initialRect.height / 2 : window.innerHeight / 2);

    const moveCursor = (e: MouseEvent) => {
      const rect = root?.getBoundingClientRect();
      cursorX.set(rect ? e.clientX - rect.left : e.clientX);
      cursorY.set(rect ? e.clientY - rect.top : e.clientY);
    };

    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);

    window.addEventListener('mousemove', moveCursor);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', moveCursor);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 pointer-events-none z-[9999] flex items-center justify-center"
      style={{
        translateX: cursorXSpring,
        translateY: cursorYSpring,
        x: '-50%',
        y: '-50%',
        opacity: isClicking ? 0.65 : 1,
        scale: isClicking ? 0.75 : 1,
      }}
    >
      <img 
        src="https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Click.png" 
        alt="brainDance cursor" 
        className="object-contain"
        style={{ width: 20, height: 20 }}
      />
    </motion.div>
  );
};

export default CustomCursor;
