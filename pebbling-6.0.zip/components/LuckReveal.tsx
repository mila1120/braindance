import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DreamSpreadResult } from '../types';
import { SPREADS } from '../data/spreads';
import { ArrowLeft } from 'lucide-react';

interface LuckRevealProps {
  fortune: DreamSpreadResult;
  category: string;
  onDone: () => void;
}

const LuckReveal: React.FC<LuckRevealProps> = ({ fortune, category, onDone }) => {
  const [step, setStep] = useState(0);

  // Default to moon if category not found
  const config = SPREADS[category] || SPREADS['moon'];
  const sections = config.sections;
  const activeSection = sections[step];
  const isFirst = step === 0;
  const isLast = step === sections.length - 1;

  const currentText = step === 0 ? fortune.coreAtmosphere :
                      step === 1 ? fortune.presentSituation :
                      step === 2 ? fortune.unfoldingPath :
                      fortune.insight;

  const activeCards = activeSection.cards;
  const displayCardNumber = activeCards[0]; // Show first card as representative

  const handleNext = () => {
    if (!isLast) setStep(s => s + 1);
    else onDone();
  };

  const mapImageSrc = "https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/bigcard.png";

  return (
    <div className="absolute inset-0 bg-black z-40 flex flex-col font-sans overflow-hidden">
      {/* Top Bar */}
      <div className="absolute top-0 left-0 w-full p-6 z-50 flex justify-between items-center">
        <button 
          onClick={onDone} 
          className="p-2 -ml-2 text-white/40 hover:text-white transition-colors bg-black/20 backdrop-blur-md rounded-full"
        >
            <ArrowLeft size={24} />
        </button>
      </div>

      {/* Main Scrollable Area */}
      <div className="flex-1 overflow-y-auto hide-scrollbar">
        <div className="min-h-full flex flex-col items-center pt-[70px] pb-40 px-6">
          <AnimatePresence mode="wait">
            <motion.div
                key={step}
                className="w-full flex flex-col items-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
            >
                {/* Card Visual */}
                <motion.div
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                    className="relative w-full aspect-square max-w-[320px] rounded-[48px] overflow-hidden bg-[#111] border border-white/5 shadow-2xl mb-6"
                >
                    {/* Texture Layers */}
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-30 mix-blend-overlay" />
                    
                    {/* Category Image Texture */}
                     <img 
                        src={mapImageSrc}
                        alt="texture"
                        onError={(e) => e.currentTarget.style.display = 'none'}
                        className="absolute inset-0 w-full h-full object-cover opacity-90"
                     />
                     
                     {/* Gradient overlay for text visibility */}
                     <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-black/50 mix-blend-multiply" />

                    {/* Big Number */}
                    <div className="absolute inset-0 flex items-center justify-center">
                        <span className="font-serif italic text-[80px] text-white/90 drop-shadow-lg tracking-tight">
                            {displayCardNumber}
                        </span>
                    </div>
                </motion.div>

                {/* Text Block */}
                <motion.div 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3, duration: 0.8 }}
                    className="w-full max-w-[340px] space-y-4"
                >
                   {/* Step Indicator Text */}
                   <p className="text-xs uppercase tracking-[0.2em] text-white/30 text-center mb-2">
                      {['I. The Core', 'II. The Situation', 'III. The Path', 'IV. Insight'][step]}
                   </p>

                   <div className="p-6 rounded-3xl bg-[#111]/40 border border-white/5 backdrop-blur-sm">
                      <p className="text-[19px] leading-[1.6] text-[#E0E0E0] font-light text-left font-sans">
                          {currentText}
                      </p>
                   </div>
                </motion.div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Control / Progress Pill - Floating above Navbar */}
      <div className="absolute bottom-32 left-0 w-full flex justify-center z-50 pointer-events-none">
         <div className="pointer-events-auto relative h-14 bg-[#1c1c1e] border border-white/10 rounded-full flex items-center pl-6 pr-2 gap-4 shadow-[0_0_40px_20px_rgba(0,0,0,0.5)] backdrop-blur-xl">
             <span className="text-white/60 font-mono text-sm tracking-widest">
                 {step + 1} <span className="text-white/20 mx-1">/</span> 4
             </span>

             <div className="h-4 w-[1px] bg-white/10" />

             <button 
                onClick={handleNext}
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-all group active:scale-95"
             >
                <div className={`w-3 h-3 border-t border-r border-white/80 transform rotate-45 transition-transform ${isLast ? '' : 'group-hover:translate-x-0.5'}`} />
             </button>
         </div>
      </div>
    </div>
  );
};

export default LuckReveal;