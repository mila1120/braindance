import React from 'react';
import { motion } from 'framer-motion';
import { Pebble } from '../types';
import { ArrowLeft } from 'lucide-react';

interface PebbleDetailProps {
  pebble: Pebble;
  onClose: () => void;
  onGenerateVideo: (pebble: Pebble) => void;
}

const PebbleDetail: React.FC<PebbleDetailProps> = ({ pebble, onClose, onGenerateVideo }) => {
  const dateStr = new Date(pebble.date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'numeric',
    day: 'numeric'
  }).replace(/\//g, '.');

  const sections = pebble.analysis.split('\n\n').filter(s => s.trim() !== '');

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] bg-black flex flex-col items-center font-sans overflow-hidden"
    >
       {/* Background Image */}
       <div className="absolute inset-0 z-0">
          <img 
            src="https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/white.png" 
            alt="Background" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-black/50" />
       </div>

      {/* Return Key */}
      <button 
        onClick={onClose}
        className="absolute top-6 left-6 z-[220] p-3 rounded-full text-white/40 hover:text-white transition-colors"
      >
        <ArrowLeft size={24} strokeWidth={1.5} />
      </button>

      {/* Header Info - Moved Upwards */}
      <div className="absolute top-[80px] w-full text-center z-20 pointer-events-none">
        <motion.h2 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-[24px] font-bold tracking-[0.1em] text-[#E5E5E5] uppercase mix-blend-overlay"
          style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}
        >
          PEBBLE {pebble.id.includes('-') ? pebble.id.split('-')[1] : pebble.id.replace(/\D/g, '')}
        </motion.h2>
        <motion.p 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-[17px] text-[#E5E5E5] font-light tracking-[0.05em] mt-1 opacity-80"
        >
          {dateStr}
        </motion.p>
      </div>

      {/* Main Content Card - Moved Upwards to align with design */}
      <motion.div 
        initial={{ y: 150, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.19, 1, 0.22, 1] }}
        className="absolute top-[160px] bottom-0 w-full max-w-md rounded-t-[48px] overflow-hidden z-10"
        style={{
           background: 'rgba(20, 20, 20, 0.4)',
           backdropFilter: 'blur(30px)',
           borderTop: '1px solid rgba(255,255,255,0.1)'
        }}
      >
        {/* Inner Scroll Container - Keeping the scrolling function */}
        <div className="w-full h-full overflow-y-auto px-8 py-12 pb-32 hide-scrollbar">
           <div className="space-y-10">
            {sections.map((section, idx) => {
              const isStructured = section.includes('**: ');
              return (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + idx * 0.1 }}
                >
                  {isStructured ? (
                    <div className="text-[16px] leading-[24px] text-[#E5E5E5]" style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif' }}>
                       {/* Render Label */}
                       <span className="block mb-1 text-white opacity-100 font-semibold tracking-wide">
                         {section.split('**: ')[0].replace(/\*+/g, '')}
                       </span>
                       {/* Render Content */}
                       <span className="font-normal opacity-80 block font-light">
                         {section.split('**: ')[1]}
                       </span>
                    </div>
                  ) : (
                    <p className="text-[16px] leading-[24px] text-[#E5E5E5] font-light opacity-90 italic">
                      {section.replace(/\*+/g, '')}
                    </p>
                  )}
                </motion.div>
              );
            })}
           </div>

           {/* Visualize Echo Checkbox/Button */}
           {!pebble.videoUrl && (
             <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               transition={{ delay: 0.8 }}
               className="mt-12 w-full flex justify-center pb-8"
             >
                <button
                  onClick={() => onGenerateVideo(pebble)}
                  className="group flex items-center gap-3 py-3 px-5 rounded-xl hover:bg-white/5 transition-colors"
                >
                  <div className="w-4 h-4 border border-[#E5E5E5]/40 rounded-[2px] flex items-center justify-center">
                    <div className="w-full h-full bg-transparent group-hover:bg-[#E5E5E5]/40 transition-colors" />
                  </div>
                  <span className="text-[11px] tracking-[0.25em] uppercase text-[#E5E5E5]/60 group-hover:text-[#E5E5E5] transition-colors font-medium">
                    Visualize Echo
                  </span>
                </button>
             </motion.div>
           )}
        </div>
        
      </motion.div>
    </motion.div>
  );
};

export default PebbleDetail;