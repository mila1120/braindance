import React from 'react';
import { motion } from 'framer-motion';
import { Pebble } from '../types';

interface NestProps {
  pebbles: Pebble[];
  onPebbleClick: (pebble: Pebble) => void;
}

// Asset mapping for the pebble variations
const PEBBLE_ASSETS = [
  'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Pebble1.png',
  'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Pebble2.png',
  'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Pebble3.png',
  'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Pebble4.png',
  'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Pebble5.png',
  'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Pebble6.png',
];

const Nest: React.FC<NestProps> = ({ pebbles, onPebbleClick }) => {
  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden bg-black">
      {/* Global Background Noise */}
      <div className="absolute inset-0 opacity-[0.05] pointer-events-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />
      
      {/* Nest Container */}
      <div className="relative w-[400px] h-[400px] flex items-center justify-center">
        
        {/* Background Nest Image */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 2 }}
          className="absolute inset-0 flex items-center justify-center z-0"
        >
          {/* Gentle Glowing Effect Behind Nest */}
          <motion.div 
            animate={{ opacity: [0.3, 0.5, 0.3], scale: [0.8, 0.9, 0.8] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute w-[300px] h-[300px] bg-white/20 rounded-full blur-[80px] -z-10"
          />

          {/* Using the Nest Asset as the background for the cluster */}
          <img 
            src="https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Nest.png" 
            alt="Nest Background" 
            className="w-full h-full object-contain opacity-100 relative z-0"
          />
        </motion.div>

        {/* Daydream Asset (Floating above) */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: [0, -8, 0] }}
          transition={{ 
            opacity: { duration: 1 },
            y: { duration: 5, repeat: Infinity, ease: "easeInOut" } 
          }}
          className="absolute -top-28 left-[calc(50%-60px)] -translate-x-1/2 z-20 w-[264px] pointer-events-none"
        >
          <img 
            src="https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Daydream.png" 
            alt="Daydream" 
            className="w-full h-auto drop-shadow-[0_0_40px_rgba(255,255,255,0.3)]"
          />
        </motion.div>

        {/* Pebbles Layer */}
        {pebbles.map((pebble, i) => {
          // Select pebble asset based on index
          const assetSrc = PEBBLE_ASSETS[i % PEBBLE_ASSETS.length];
          const delay = i * 0.1;

          return (
            <motion.div
              key={pebble.id}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ 
                opacity: 1,
                scale: pebble.scale,
                x: pebble.position.x,
                y: pebble.position.y
              }}
              transition={{ 
                duration: 1.8,
                delay: delay,
                type: "spring",
                stiffness: 35,
                damping: 20
              }}
              className="absolute top-1/2 left-1/2 -ml-10 -mt-10 cursor-pointer z-10 group"
              onClick={() => onPebbleClick(pebble)}
            >
              <motion.div 
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
                className="relative w-20 h-20 flex items-center justify-center"
              >
                <img 
                  src={assetSrc} 
                  alt={`Pebble ${i + 1}`}
                  className="w-full h-full object-contain drop-shadow-[0_5px_15px_rgba(0,0,0,0.8)] transition-all duration-300 group-hover:drop-shadow-[0_0_20px_rgba(255,255,255,0.5)]"
                />
                
                {/* Fallback / Enhancement Glow */}
                <div 
                  className="absolute inset-2 rounded-full opacity-20 blur-md -z-10 transition-colors duration-500"
                  style={{ backgroundColor: pebble.color }}
                />
              </motion.div>
            </motion.div>
          );
        })}

        {pebbles.length === 0 && (
           <div className="absolute inset-0 flex items-center justify-center opacity-30 z-0">
              <p className="text-[10px] tracking-[0.5em] uppercase text-white font-light">Empty Nest</p>
           </div>
        )}
      </div>
    </div>
  );
};

export default Nest;