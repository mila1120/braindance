import React from 'react';
import { motion } from 'framer-motion';

interface LuckDashboardProps {
  onSelectCategory: (category: string) => void;
  onBack: () => void;
}

const LuckDashboard: React.FC<LuckDashboardProps> = ({ onSelectCategory }) => {
  const dailyCards = [
    { id: 'color', label: 'Color', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/1.png' },
    { id: 'food', label: 'Food', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/2.png' },
    { id: 'number', label: 'Number', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/3.png' },
  ];

  const analysisCards = [
    { id: 'moon', label: 'Moon', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/4.png' },
    { id: 'insane', label: 'Insane', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/5.png' },
    { id: 'dream', label: 'Dream', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/Dream.png' },
    { id: 'flow', label: 'Flow of Music', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/Flowofmusic.png' },
    { id: 'protection', label: 'Protection', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/Happy.png' },
    { id: 'happiness', label: 'Happiness', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/Happiness.png' },
    { id: 'anxiety', label: 'Anxiety', image: 'https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Card%20choosing/Anxiety.png' },

  ];

  return (
    <div className="absolute inset-0 bg-black flex flex-col z-10 font-sans">
      {/* Spacer for status bar area */}
      <div className="h-16 shrink-0" />

      <div className="flex-1 overflow-y-auto px-6 pb-40 hide-scrollbar">
        {/* Daily Fortune */}
        <div className="mb-12">
          <motion.h2 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-[19px] font-medium text-white mb-6 tracking-tight"
          >
            Daily Fortune
          </motion.h2>
          
          <div className="grid grid-cols-3 gap-3">
            {dailyCards.map((card, i) => (
              <motion.button
                key={card.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                onClick={() => onSelectCategory(card.id)}
                className="flex flex-col gap-3 group text-left"
              >
                <div className="aspect-square w-full rounded-2xl overflow-hidden bg-[#111] border border-white/5 relative">
                   <img 
                     src={card.image} 
                     alt={card.label} 
                     className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-all duration-500 grayscale-[0.2]" 
                   />
                   <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-50" />
                </div>
                <span className="text-[15px] font-light text-white/70 tracking-wide pl-1">{card.label}</span>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Dream Analysis */}
        <div>
          <motion.h2 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="text-[19px] font-medium text-white mb-6 tracking-tight"
          >
            Spreads
          </motion.h2>
          
          <div className="grid grid-cols-2 gap-4">
             {analysisCards.map((card, i) => (
              <motion.button
                key={card.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + (i * 0.1) }}
                onClick={() => onSelectCategory(card.id)}
                className="flex flex-col gap-3 group text-left"
              >
                <div className="aspect-[0.9] w-full rounded-[2rem] overflow-hidden bg-[#111] border border-white/5 relative shadow-2xl">
                   <img 
                     src={card.image} 
                     alt={card.label} 
                     className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-all duration-700 scale-105 group-hover:scale-100 grayscale-[0.3]" 
                   />
                   {/* Subtle inner shadow for depth */}
                   <div className="absolute inset-0 shadow-[inset_0_0_40px_rgba(0,0,0,0.5)]" />
                </div>
                <span className="text-[15px] font-light text-white/70 tracking-wide pl-1">{card.label}</span>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LuckDashboard;