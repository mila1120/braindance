import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Send, X, ArrowRight, ArrowLeft } from 'lucide-react';

interface DreamInputProps {
  onCancel: () => void;
  onSubmit: (text: string) => void;
  isProcessing: boolean;
  showCancel?: boolean;
}

const DreamInput: React.FC<DreamInputProps> = ({ onCancel, onSubmit, isProcessing, showCancel = true }) => {
  const [text, setText] = useState('');

  const wordCount = useMemo(() => {
    return text.trim().split(/\s+/).filter(w => w.length > 0).length;
  }, [text]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (text.trim() && wordCount <= 100) {
      onSubmit(text);
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setText(val);
  };

  const isOverLimit = wordCount > 100;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 z-[95] bg-black flex flex-col"
    >
      {/* Return Key */}
      {showCancel && (
        <div className="absolute top-6 left-6 z-[100]">
          <button 
            onClick={onCancel} 
            className="p-3 rounded-full bg-white/5 hover:bg-white/10 transition-colors text-white/40 hover:text-white"
          >
            <ArrowLeft size={24} strokeWidth={1.5} />
          </button>
        </div>
      )}

      <div className="flex-1 flex flex-col justify-center px-10 pb-20">
        <div className="max-w-xl w-full mx-auto space-y-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 1 }}
          >
            <h2 className="text-[42px] leading-[1.15] font-light text-white tracking-tight">
              Tell me about <br/>
              <span className="text-white">your dream</span>
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1.5 }}
            className="relative"
          >
            <textarea
              value={text}
              onChange={handleTextChange}
              placeholder="..."
              className="w-full bg-transparent text-gray-300 text-2xl font-light placeholder-gray-800 focus:outline-none resize-none min-h-[160px] hide-scrollbar"
              autoFocus
            />
            
            {/* Word Count Indicator */}
            <div className={`mt-4 text-[10px] tracking-widest uppercase font-medium ${isOverLimit ? 'text-red-500/60' : 'text-white/20'}`}>
              {wordCount} / 100 words
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Action Area */}
      <div className="absolute bottom-16 right-12 z-[110]">
        <motion.button
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: text.trim() ? 1 : 0.3, scale: 1 }}
          onClick={(e) => {
            e.stopPropagation();
            handleSubmit();
          }}
          disabled={!text.trim() || isProcessing || isOverLimit}
          className={`
            w-20 h-20 rounded-full flex items-center justify-center transition-all duration-500
            ${text.trim() && !isProcessing && !isOverLimit ? 'bg-white/90 text-black shadow-[0_0_30px_rgba(255,255,255,0.2)] active:scale-90' : 'bg-white/10 text-white/20'}
          `}
        >
          {isProcessing ? (
            <div className="w-6 h-6 border-2 border-black/40 border-t-transparent rounded-full animate-spin" />
          ) : (
            <div className="relative pointer-events-none">
               <div className="absolute inset-0 blur-md bg-black/10 rounded-full" />
               <ArrowRight size={32} className="relative z-10" />
            </div>
          )}
        </motion.button>
      </div>

      {/* Floating background fragment visual */}
      <div className="absolute top-1/2 right-10 -translate-y-1/2 pointer-events-none">
        <motion.div
           animate={{ 
             y: [0, -10, 0],
             scale: [0.98, 1.02, 0.98]
           }}
           transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
           className="w-32 h-32 rounded-full bg-white/5 blur-[20px]"
        />
      </div>
    </motion.div>
  );
};

export default DreamInput;