import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';

const DAYS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const MONTHS = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'];
const HEAT_COLORS = ['#17171a', '#24334f', '#31589b', '#3f73e6', '#78a1ff'];

interface HeatCell {
  id: string;
  level: number;
  dreams: number;
  label: string;
}

const PersonalityPie: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const size = 152;
    const density = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size * density;
    canvas.height = size * density;
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;

    const context = canvas.getContext('2d');
    if (!context) return;
    context.scale(density, density);

    const segments = [
      { value: 68.5, color: '#6f9dff' },
      { value: 11.5, color: '#65d1d0' },
      { value: 20, color: '#242429' },
    ];

    let startAngle = -Math.PI / 2;
    segments.forEach((segment) => {
      const endAngle = startAngle + (segment.value / 100) * Math.PI * 2;
      context.beginPath();
      context.moveTo(size / 2, size / 2);
      context.arc(size / 2, size / 2, size / 2 - 3, startAngle, endAngle);
      context.closePath();
      context.fillStyle = segment.color;
      context.fill();
      context.strokeStyle = '#101012';
      context.lineWidth = 3;
      context.stroke();
      startAngle = endAngle;
    });
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="block shrink-0"
      role="img"
      aria-label="Personality profile: 68.5 percent reflective, 11.5 percent intuitive, and 20 percent uncharted"
    />
  );
};

const InsightsDashboard: React.FC = () => {
  const [selectedCell, setSelectedCell] = useState<HeatCell | null>(null);
  const [showReport, setShowReport] = useState(false);

  const heatmap = useMemo<HeatCell[]>(() => {
    const start = new Date('2026-04-05T12:00:00');
    const rankedActivity = Array.from({ length: 24 * 7 - 49 }, (_, offset) => {
      const index = offset + 49;
      const column = Math.floor(index / 7);
      const day = index % 7;
      return { index, score: (column * 11 + day * 7 + column * day * 3) % 97 };
    })
      .sort((a, b) => b.score - a.score)
      .slice(0, 69);
    const activeCells = new Set(rankedActivity.map(({ index }) => index));

    return Array.from({ length: 24 * 7 }, (_, index) => {
      const column = Math.floor(index / 7);
      const day = index % 7;
      const date = new Date(start);
      date.setDate(start.getDate() + column * 7 + day);

      const intensity = (column * 5 + day * 3 + column * day) % 4;
      const level = activeCells.has(index) ? intensity + 1 : 0;

      return {
        id: `${column}-${day}`,
        level,
        dreams: level === 0 ? 0 : level,
        label: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      };
    });
  }, []);

  return (
    <motion.main
      key="insights"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="absolute inset-0 z-10 overflow-y-auto bg-[#070708] px-5 pb-40 pt-12 hide-scrollbar"
    >
      <header className="mb-7 px-1">
        <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.2em] text-white/35">Dream archive</p>
        <h1 className="text-[34px] font-medium tracking-[-0.04em] text-white">Insights</h1>
        <p className="mt-2 text-[14px] font-light text-white/45">Your patterns, one night at a time.</p>
      </header>

      <section aria-label="Dream activity summary" className="mb-4 grid grid-cols-3 gap-2">
        {[
          { value: '69', label: 'Active days' },
          { value: '1', label: 'Current streak' },
          { value: '12', label: 'Longest streak' },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 + index * 0.06 }}
            className="rounded-[22px] border border-white/[0.06] bg-[#101012] px-3 py-4"
          >
            <div className="text-[29px] font-medium leading-none tracking-[-0.04em] text-white">{stat.value}</div>
            <div className="mt-2 min-h-8 text-[10px] font-medium uppercase leading-4 tracking-[0.08em] text-white/35">
              {stat.label}
            </div>
          </motion.div>
        ))}
      </section>

      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.18 }}
        aria-labelledby="activity-title"
        className="mb-4 rounded-[28px] border border-white/[0.07] bg-[#101012] px-4 pb-5 pt-5"
      >
        <div className="mb-5 flex items-end justify-between">
          <div>
            <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-white/30">Apr — Sep 2026</p>
            <h2 id="activity-title" className="mt-1 text-[18px] font-medium tracking-tight text-white/90">Dream activity</h2>
          </div>
          <span className="text-[12px] text-[#78a1ff]">69 nights</span>
        </div>

        <div className="grid grid-cols-[13px_1fr] gap-x-2">
          <div className="grid grid-rows-7 gap-[4px] pt-0.5">
            {DAYS.map((day, index) => (
              <span key={`${day}-${index}`} className="flex items-center text-[8px] text-white/25">{day}</span>
            ))}
          </div>

          <div>
            <div className="grid grid-flow-col grid-cols-24 grid-rows-7 gap-[4px]">
              {heatmap.map((cell) => (
                <button
                  key={cell.id}
                  type="button"
                  onClick={() => setSelectedCell(cell)}
                  aria-label={`${cell.label}: ${cell.dreams} dream${cell.dreams === 1 ? '' : 's'}`}
                  className="aspect-square min-w-0 rounded-[3px] border border-white/[0.035] transition-transform hover:scale-125 focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-1 focus-visible:outline-[#78a1ff]"
                  style={{ backgroundColor: HEAT_COLORS[cell.level] }}
                />
              ))}
            </div>

            <div className="mt-3 grid grid-cols-6 text-[8px] uppercase tracking-[0.08em] text-white/22">
              {MONTHS.map((month) => <span key={month}>{month}</span>)}
            </div>
          </div>
        </div>

        <div className="mt-5 flex min-h-5 items-center justify-between border-t border-white/[0.06] pt-4">
          <p aria-live="polite" className="text-[10px] text-white/40">
            {selectedCell ? `${selectedCell.label} · ${selectedCell.dreams || 'No'} dream${selectedCell.dreams === 1 ? '' : 's'}` : 'Tap a square for details'}
          </p>
          <div className="flex items-center gap-1.5" aria-label="Activity intensity from less to more">
            <span className="mr-1 text-[8px] uppercase tracking-[0.08em] text-white/25">Less</span>
            {HEAT_COLORS.map((color) => (
              <span key={color} className="h-2.5 w-2.5 rounded-[3px] border border-white/[0.04]" style={{ backgroundColor: color }} />
            ))}
            <span className="ml-1 text-[8px] uppercase tracking-[0.08em] text-white/25">More</span>
          </div>
        </div>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.26 }}
        aria-labelledby="personality-title"
        className="rounded-[28px] border border-white/[0.07] bg-[#101012] p-5"
      >
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-white/30">Personality</p>
            <h2 id="personality-title" className="mt-2 text-[36px] font-medium leading-none tracking-[-0.045em] text-white">68.5%</h2>
            <p className="mt-2 text-[15px] font-light text-white/50">Reflective dreamer</p>
            <button
              type="button"
              onClick={() => setShowReport((visible) => !visible)}
              aria-expanded={showReport}
              className="mt-5 rounded-full border border-white/[0.08] bg-white/[0.06] px-4 py-2 text-[11px] font-medium text-white/70 transition-colors hover:bg-white/[0.1] hover:text-white"
            >
              {showReport ? 'Hide report' : 'View report'}
            </button>
          </div>
          <PersonalityPie />
        </div>

        <div id="personality-legend" className="mt-5 grid grid-cols-3 gap-2 border-t border-white/[0.06] pt-4">
          {[
            { color: '#6f9dff', label: 'Reflective', value: '68.5%' },
            { color: '#65d1d0', label: 'Intuitive', value: '11.5%' },
            { color: '#242429', label: 'Uncharted', value: '20%' },
          ].map((item) => (
            <div key={item.label} className="min-w-0">
              <span className="mb-2 block h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
              <div className="truncate text-[9px] uppercase tracking-[0.06em] text-white/30">{item.label}</div>
              <div className="mt-1 text-[13px] font-medium text-white/75">{item.value}</div>
            </div>
          ))}
        </div>

        {showReport && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-5 overflow-hidden border-t border-white/[0.06] pt-4"
          >
            <p className="text-[12px] font-light leading-5 text-white/50">
              You tend to remember atmosphere before plot. Quiet details, recurring places, and emotional shifts carry the strongest signals in your archive.
            </p>
          </motion.div>
        )}
      </motion.section>
    </motion.main>
  );
};

export default InsightsDashboard;
