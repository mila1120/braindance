import React from 'react';
import { ViewState } from '../types';
import { MessageSquare, Circle, Sparkle, Moon } from 'lucide-react';

interface NavBarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
}

const NavBar: React.FC<NavBarProps> = ({ currentView, onChangeView }) => {
  const tabs = [
    { id: 'NEST', label: 'Pebble Jar', icon: Circle },
    { id: 'ANALYSE', label: 'Analyse', icon: Sparkle },
    { id: 'LUCK', label: 'Luck', icon: Moon },
    { id: 'CHAT', label: 'Friends', icon: MessageSquare },
  ];

  const isLuckActive = currentView === 'LUCK' || currentView === 'LUCK_INPUT' || currentView === 'LUCK_SELECTING' || currentView === 'LUCK_REVEAL';

  return (
    <div className="fixed bottom-0 left-0 w-full px-6 pb-12 pt-4 bg-gradient-to-t from-black via-black/80 to-transparent z-[250]">
      <div className="flex justify-between items-center max-w-md mx-auto">
        {tabs.map((tab) => {
          const isActive = tab.id === 'NEST' ? (currentView === 'NEST' || currentView === 'PEBBLE_DETAIL') : 
                          tab.id === 'ANALYSE' ? (currentView === 'ADD_DREAM' || currentView === 'ANALYZING') :
                          tab.id === 'LUCK' ? isLuckActive :
                          tab.id === 'CHAT' ? (currentView === 'CHAT') : false;
          
          const Icon = tab.icon;
          
          return (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.id === 'NEST') onChangeView('NEST');
                if (tab.id === 'LUCK') onChangeView('LUCK');
                if (tab.id === 'ANALYSE') onChangeView('ADD_DREAM');
                if (tab.id === 'CHAT') onChangeView('CHAT');
              }}
              className="flex flex-col items-center gap-3 group transition-all duration-300"
            >
              <div 
                className={`
                  w-14 h-14 rounded-full flex items-center justify-center transition-all duration-500 relative
                  ${isActive ? 'bg-white/10 scale-105' : 'bg-transparent'}
                  hover:bg-white/5 active:scale-95
                `}
              >
                <div className={`transition-all duration-300 ${isActive ? 'text-white' : 'text-white/30'}`}>
                   <Icon 
                     size={26} 
                     fill={isActive ? "currentColor" : "none"} 
                     strokeWidth={1.5} 
                     className="relative z-10"
                   />
                </div>
                
                {/* Active Inner Glow */}
                {isActive && (
                  <div className="absolute inset-0 bg-white/10 blur-xl pointer-events-none rounded-full" />
                )}
              </div>
              
              <span className={`text-[10px] uppercase tracking-[0.05em] font-medium transition-colors duration-300 ${isActive ? 'text-white' : 'text-white/40'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default NavBar;