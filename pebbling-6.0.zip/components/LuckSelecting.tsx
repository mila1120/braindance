import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SPREADS } from '../data/spreads';

interface LuckSelectingProps {
  onSelected: () => void;
  category?: string;
}

const LuckSelecting: React.FC<LuckSelectingProps> = ({ onSelected, category = 'moon' }) => {
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    // Start ripple animation at 4.5s
    const rippleTimer = setTimeout(() => setIsTransitioning(true), 4500);
    // Navigate at 6.5s
    const timer = setTimeout(onSelected, 6500);
    
    return () => {
        clearTimeout(rippleTimer);
        clearTimeout(timer);
    };
  }, [onSelected]);

  const config = SPREADS[category] || SPREADS['moon'];
  const cards = config.layout;

  return (
    <div className="absolute inset-0 bg-black z-30 flex flex-col font-sans overflow-hidden">
      
      {/* Title */}
      <motion.div 
         initial={{ opacity: 0, y: -20 }} 
         animate={{ opacity: 1, y: 0 }} 
         className="absolute top-16 left-8 z-20"
      >
         <h2 className="text-5xl font-light text-white tracking-wide">{config.title}</h2>
      </motion.div>

      {/* Cards Area */}
      <div className="relative flex-1 w-full max-w-md mx-auto pointer-events-none z-10 mt-10">
        <div className="relative w-full h-full">
            {cards.map((card, i) => (
            <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ 
                delay: 0.2 + (i * 0.1),
                duration: 0.6,
                ease: "easeOut"
                }}
                style={{ 
                top: card.top, 
                left: card.left, 
                x: "-50%", 
                y: "-50%",
                rotate: card.rotate || 0
                }}
                className="absolute w-[60px] h-[85px] rounded-lg border-[0.5px] border-white/20 bg-gradient-to-b from-[#333] to-[#1c1c1e] shadow-2xl flex items-center justify-center overflow-hidden"
            >
                {/* Card Noise Texture */}
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-50 mix-blend-overlay" />
                
                {/* Inner Bevel/Light */}
                <div className="absolute inset-0 border-[0.5px] border-white/10 rounded-lg" />

                <span className="font-serif text-[#8e8e93] text-2xl relative z-10">{card.n}</span>
            </motion.div>
            ))}
        </div>
      </div>
      
      {/* Bottom Slider UI */}
      <div className="absolute bottom-12 left-0 w-full px-8 flex justify-center z-20">
        <div className="w-full max-w-[340px] h-16 rounded-full border border-white/20 bg-[#1c1c1e] flex items-center justify-between px-6 relative overflow-hidden backdrop-blur-md">
            
            {/* Left Icon (Bar) */}
            <div className="text-white/50 text-xl font-light">|</div>
            
            {/* Sliding Highlight */}
            <motion.div 
               initial={{ x: "-100%" }}
               animate={{ x: "100%" }}
               transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
               className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent pointer-events-none"
            />

            {/* Right Circle Knob */}
            <div className="relative">
                <motion.div 
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-8 h-8 rounded-full bg-gradient-to-b from-[#555] to-[#333] border border-white/10 shadow-lg flex items-center justify-center"
                >
                    <div className="w-full h-full rounded-full bg-white/10 blur-[2px]" />
                </motion.div>
                
                {/* Glow behind knob */}
                <div className="absolute inset-0 bg-white/20 blur-md rounded-full -z-10" />
            </div>

            {/* Progress Fill Indicator */}
             <motion.div 
               initial={{ width: "0%" }}
               animate={{ width: "100%" }}
               transition={{ duration: 6, ease: "linear" }}
               className="absolute left-0 bottom-0 h-[2px] bg-white/20"
            />
        </div>
      </div>

      {/* Transition Ripples */}
      <AnimatePresence>
        {isTransitioning && (
           <div className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none overflow-hidden">
              {[0, 1, 2, 3].map((i) => (
                  <motion.div 
                     key={i}
                     initial={{ width: 0, height: 0, opacity: 0.8, borderWidth: '2px' }}
                     animate={{ width: '200vmax', height: '200vmax', opacity: 0, borderWidth: '0px' }}
                     transition={{ duration: 2.5, ease: "easeOut", delay: i * 0.3 }}
                     className="absolute rounded-full border-white bg-transparent box-border"
                  />
              ))}
              <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 1, delay: 1 }}
                  className="absolute inset-0 bg-black"
              />
           </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default LuckSelecting;