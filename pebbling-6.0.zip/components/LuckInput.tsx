import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';

interface LuckInputProps {
  onBack: () => void;
  onSubmit: (question: string) => void;
}

const LuckInput: React.FC<LuckInputProps> = ({ onBack, onSubmit }) => {
  const [question, setQuestion] = useState('');

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (question.trim()) onSubmit(question);
  };

  return (
    <div className="absolute inset-0 bg-black z-20 flex flex-col p-8">
      <div className="absolute top-6 left-6 z-50">
        <button 
          onClick={onBack} 
          className="p-3 rounded-full bg-white/5 text-white/40 hover:text-white hover:bg-white/10 transition-colors"
        >
          <ArrowLeft size={24} strokeWidth={1.5} />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center text-center space-y-12">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative w-40 h-24"
        >
          <div className="absolute inset-0 bg-white/5 blur-3xl rounded-full" />
        </motion.div>

        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           className="space-y-4"
        >
          <h2 className="text-3xl font-light text-white/80 leading-tight">
            Ask about today's<br />lucky color, food, or number.
          </h2>
        </motion.div>
      </div>

      <div className="pb-32 px-4">
        <div className="relative flex items-center bg-[#1a1a1a] rounded-full px-6 py-4 border border-white/5 shadow-2xl group focus-within:border-white/20 transition-colors">
          <input 
            autoFocus
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            className="flex-1 bg-transparent text-white placeholder-white/10 text-lg outline-none font-light"
            placeholder="I am feeling..."
          />
          <button 
            onClick={() => handleSubmit()}
            disabled={!question.trim()}
            className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/40 hover:bg-white/10 transition-colors disabled:opacity-20"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-500 to-gray-800 border border-white/20" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default LuckInput;