import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { X, Upload, Loader2, Video as VideoIcon, ArrowLeft } from 'lucide-react';
import { generateDreamVideo } from '../services/gemini';
import { Pebble } from '../types';

interface VeoStudioProps {
  pebble: Pebble;
  onClose: () => void;
  onVideoGenerated: (url: string) => void;
}

const VeoStudio: React.FC<VeoStudioProps> = ({ pebble, onClose, onVideoGenerated }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit check mock
         setError("Image too large. Please select under 5MB.");
         return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!selectedImage) return;

    setIsGenerating(true);
    setError(null);

    try {
      // Parse data URL: data:[<mediatype>][;base64],<data>
      const match = selectedImage.match(/^data:(.+);base64,(.+)$/);
      if (!match) throw new Error("Invalid image format");
      
      const mimeType = match[1];
      const base64Data = match[2];

      const videoUrl = await generateDreamVideo(base64Data, mimeType, `A dreamlike, cinematic video of: ${pebble.dreamText}`);
      if (videoUrl) {
        onVideoGenerated(videoUrl);
      } else {
         setError("Failed to generate video.");
      }
    } catch (err: any) {
        console.error(err);
        let msg = "Something went wrong.";
        if (err.message?.includes("API Key")) msg = "API Key issue. Ensure you select a paid project.";
        else if (err.message) msg = err.message;
        setError(msg);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <motion.div 
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      className="fixed inset-0 z-50 bg-black flex flex-col"
    >
      <div className="flex items-center justify-between p-6">
        <button 
          onClick={onClose} 
          className="p-3 rounded-full bg-white/5 text-white/40 hover:text-white hover:bg-white/10 transition-colors"
        >
           <ArrowLeft size={24} strokeWidth={1.5} />
        </button>
        <h3 className="text-lg font-light tracking-wide absolute left-1/2 -translate-x-1/2">Veo Studio</h3>
        <div className="w-10" /> {/* Spacer for balance */}
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-8">
        {!selectedImage ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-full max-w-sm aspect-video rounded-xl border border-dashed border-gray-700 bg-gray-900/30 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-900/50 transition-colors"
          >
            <Upload size={32} className="text-gray-500 mb-4" />
            <p className="text-gray-400 text-sm">Upload a reference photo</p>
            <p className="text-gray-600 text-xs mt-2">To guide the dream visualization</p>
          </div>
        ) : (
          <div className="relative w-full max-w-sm rounded-xl overflow-hidden border border-gray-800">
            <img src={selectedImage} alt="Reference" className="w-full object-cover opacity-80" />
            <button 
                onClick={() => setSelectedImage(null)}
                className="absolute top-2 right-2 p-1 bg-black/50 rounded-full"
            >
                <X size={16} />
            </button>
          </div>
        )}

        <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/*" 
            className="hidden" 
        />

        {error && <p className="text-red-400 text-sm px-4 text-center">{error}</p>}

        <button
          onClick={handleGenerate}
          disabled={!selectedImage || isGenerating}
          className={`
            w-full max-w-sm py-4 rounded-full font-medium tracking-wide flex items-center justify-center gap-2
            ${!selectedImage || isGenerating ? 'bg-gray-800 text-gray-500 cursor-not-allowed' : 'bg-white text-black hover:bg-gray-200'}
          `}
        >
          {isGenerating ? (
            <>
              <Loader2 size={20} className="animate-spin" />
              Dreaming... (this takes time)
            </>
          ) : (
            <>
              <VideoIcon size={20} />
              Generate Video
            </>
          )}
        </button>
        
        <div className="px-6 text-center text-xs text-gray-600">
            <p>Powered by Veo 3.1. Requires a paid account selection.</p>
        </div>
      </div>
    </motion.div>
  );
};

export default VeoStudio;