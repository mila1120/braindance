import React from 'react';
import { motion } from 'framer-motion';
import { X, Cpu, Cloud, Zap, Brain } from 'lucide-react';

interface ArchitectureDiagramProps {
  onClose: () => void;
}

const ArchitectureDiagram: React.FC<ArchitectureDiagramProps> = ({ onClose }) => {
  const steps = [
    { icon: <Zap size={20} />, title: "Input", desc: "User logs a dream via text or voice.", color: "bg-blue-500" },
    { icon: <Brain size={20} />, title: "Analysis", desc: "Gemini 3 Flash extracts symbols and mood.", color: "bg-purple-500" },
    { icon: <Cpu size={20} />, title: "Processing", desc: "State management updates the Nest visualization.", color: "bg-pink-500" },
    { icon: <Cloud size={20} />, title: "Generation", desc: "Veo 3.1 creates high-fidelity video reflections.", color: "bg-indigo-500" },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-2xl flex items-center justify-center p-6"
    >
      <div className="max-w-md w-full bg-gray-900/50 border border-white/10 rounded-[2rem] p-8 relative">
        <button onClick={onClose} className="absolute top-6 right-6 text-gray-500 hover:text-white">
          <X size={24} />
        </button>
        
        <h2 className="text-2xl font-light mb-8 text-center tracking-tight">System Architecture</h2>
        
        <div className="space-y-8 relative">
          <div className="absolute left-6 top-4 bottom-4 w-[1px] bg-gradient-to-b from-white/20 via-white/5 to-white/20" />
          
          {steps.map((step, i) => (
            <motion.div 
              key={i}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: i * 0.1 }}
              className="flex gap-6 relative"
            >
              <div className={`w-12 h-12 rounded-full ${step.color} flex items-center justify-center text-white shadow-xl flex-shrink-0 z-10`}>
                {step.icon}
              </div>
              <div>
                <h3 className="font-medium text-gray-200">{step.title}</h3>
                <p className="text-sm text-gray-500 mt-1">{step.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-white/5 text-center">
          <p className="text-[10px] uppercase tracking-[0.2em] text-gray-600">Powered by Gemini & Veo</p>
        </div>
      </div>
    </motion.div>
  );
};

export default ArchitectureDiagram;