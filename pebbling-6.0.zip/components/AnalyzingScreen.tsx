import React from 'react';
import { motion } from 'framer-motion';

const AnalyzingScreen: React.FC = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.8 } }}
      className="absolute inset-0 z-[150] bg-black flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <motion.div 
        initial={{ opacity: 0, scale: 1.1 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 2, ease: "easeOut" }}
        className="absolute inset-0 z-0"
      >
        <img 
          src="https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/white2.png" 
          alt="Background" 
          className="w-full h-full object-cover opacity-80" 
        />
        {/* Overlay for contrast */}
        <div className="absolute inset-0 bg-black/40" />
      </motion.div>

      {/* Central Animation Container */}
      <div className="absolute inset-0 flex flex-col items-center justify-center z-10 pointer-events-none">
        
        {/* Ripples & Core */}
        <div className="relative flex items-center justify-center">
            {/* Meditative ripples */}
            {[1, 2, 3].map((i) => (
            <motion.div
                key={i}
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 3, opacity: 0 }}
                transition={{
                duration: 4,
                repeat: Infinity,
                delay: i * 1,
                ease: "easeOut",
                }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 border border-white/30 rounded-full"
            />
            ))}
            
            {/* Pulsing Pebble Core */}
            <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{
                    scale: [1, 1.1, 1],
                    opacity: [0.6, 1, 0.6],
                }}
                transition={{ 
                    scale: { delay: 0.2, duration: 0.8, ease: "backOut" },
                    default: { duration: 3, repeat: Infinity, ease: "easeInOut", delay: 1 } 
                }}
                className="w-16 h-16 bg-white/90 rounded-full blur-[1px] relative z-10 shadow-[0_0_30px_rgba(255,255,255,0.3)]"
            />
        </div>

        {/* Caption */}
        <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 1 }}
            className="mt-24 text-[10px] uppercase tracking-[0.8em] text-white/60 font-light text-center px-6"
        >
            Listening to your echoes...
        </motion.p>
      </div>
    </motion.div>
  );
};

export default AnalyzingScreen;