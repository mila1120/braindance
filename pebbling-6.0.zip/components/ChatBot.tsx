import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ArrowLeft } from 'lucide-react';
import { createChat } from '../services/gemini';
import { ChatMessage } from '../types';

interface ChatBotProps {
  onClose: () => void;
}

const ChatBot: React.FC<ChatBotProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', role: 'model', text: 'What part of yourself would you like to understand a little better today?', timestamp: Date.now() }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatSession = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatSession.current = createChat();
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      if (chatSession.current) {
        const result = await chatSession.current.sendMessage({ message: userMsg.text });
        const modelMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'model',
          text: result.text || "",
          timestamp: Date.now()
        };
        setMessages(prev => [...prev, modelMsg]);
      }
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "The ripples are silent...", timestamp: Date.now() }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="absolute inset-0 z-[200] bg-black flex flex-col font-sans">
      {/* Return Key */}
      <button 
        onClick={onClose}
        className="absolute top-6 left-6 z-[220] p-3 -ml-2 rounded-full text-white/40 hover:text-white transition-colors"
      >
        <ArrowLeft size={24} strokeWidth={1.5} />
      </button>

      {/* Grainy Texture Overlay */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')] z-50" />

      {/* Header - Horizontal Layout with Logo */}
      <div className="absolute top-0 left-0 w-full pt-8 pb-4 flex items-center justify-center z-10 pointer-events-none">
          <div className="flex items-center gap-3">
              {/* brainDance Logo Avatar */}
              <div className="w-10 h-10 rounded-full flex items-center justify-center overflow-hidden">
                 <img 
                   src="https://raw.githubusercontent.com/maychoy1120-coder/Pebble/main/Pebble1.png" 
                   alt="brainDance Logo" 
                   className="w-full h-full object-contain"
                 />
              </div>
              <span className="text-[17px] font-medium text-white tracking-wide">brainDance</span>
          </div>
      </div>

      <div className="w-full h-4 shrink-0" /> {/* Spacer */}

      {/* Chat Area */}
      <div 
        ref={scrollRef} 
        className="flex-1 overflow-y-auto px-6 pt-28 space-y-6 pb-60 hide-scrollbar z-10"
      >
        {messages.map((msg) => (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            key={msg.id} 
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`
                max-w-[85%] px-5 py-4 rounded-[1.5rem] text-[16px] leading-[1.5]
                ${msg.role === 'user' 
                  ? 'bg-white/10 text-white/90 border border-white/5' 
                  : 'bg-[#1c1c1e] text-[#E0E0E0] shadow-lg border border-white/5'
                }
              `}
            >
              {msg.text}
            </div>
          </motion.div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-[#1c1c1e] px-5 py-4 rounded-[1.5rem] flex gap-1.5 items-center shadow-lg border border-white/5">
               <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-bounce" />
               <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-bounce [animation-delay:0.2s]" />
               <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-bounce [animation-delay:0.4s]" />
             </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="absolute bottom-[143px] left-0 w-full px-6 z-[210]">
        <div className="relative flex items-center bg-[#0a0a0a] border border-white/10 rounded-full px-5 py-4 shadow-2xl">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask the guide"
            className="flex-1 bg-transparent text-white placeholder-white/20 text-[16px] focus:outline-none tracking-wide pl-2"
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="ml-3 text-white/30 hover:text-white transition-colors disabled:opacity-10"
          >
            <ArrowUpRight size={22} strokeWidth={1.5} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatBot;
